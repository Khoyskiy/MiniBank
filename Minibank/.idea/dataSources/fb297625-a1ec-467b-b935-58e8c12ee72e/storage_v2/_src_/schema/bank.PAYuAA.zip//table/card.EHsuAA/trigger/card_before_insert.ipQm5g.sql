create definer = root@localhost trigger Card_BEFORE_INSERT
    before insert
    on card
    for each row
BEGIN
SET NEW.Card_number = CONCAT(
        CASE WHEN RAND() < 0.5 THEN '4' ELSE '5' END,
        LPAD(FLOOR(RAND() * 1000), 3, '0'),
        LPAD(FLOOR(RAND() * 1000), 3, '0'),
        LPAD(FLOOR(RAND() * 1000), 3, '0'),
        LPAD(FLOOR(RAND() * 1000), 3, '0')
    );
END;

