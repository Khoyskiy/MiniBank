create definer = root@localhost trigger client_BEFORE_INSERT
    before insert
    on client
    for each row
BEGIN
	 DECLARE user_age INT;
	 SET user_age = YEAR(CURDATE()) - YEAR(NEW.BirthDay);
      IF user_age >= 14 AND user_age < 18 THEN
        SET NEW.Underaged = TRUE;
    ELSE
        SET NEW.Underaged = FALSE;
    END IF;
END;

