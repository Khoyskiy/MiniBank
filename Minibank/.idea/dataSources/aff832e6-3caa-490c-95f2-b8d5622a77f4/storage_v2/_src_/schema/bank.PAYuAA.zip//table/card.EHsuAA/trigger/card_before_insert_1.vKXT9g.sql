create definer = root@localhost trigger Card_BEFORE_INSERT_1
    before insert
    on card
    for each row
BEGIN
SET NEW.CVC =  FLOOR(100 + RAND() * 900);
END;

